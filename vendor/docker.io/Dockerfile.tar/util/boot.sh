#!/bin/bash

wget $1

node http_server.js
